/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:54:01 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for period
-- ----------------------------
DROP TABLE IF EXISTS "period";
CREATE TABLE "period" (
	 "period" varchar(20,0) NOT NULL,
	 "date" text(20,0) NOT NULL
);

-- ----------------------------
--  Records of period
-- ----------------------------
BEGIN;
INSERT INTO "period" VALUES ('选课', '2016-06-15 09:52:51');
COMMIT;

PRAGMA foreign_keys = true;
