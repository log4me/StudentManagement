/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:53:31 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS "user";
CREATE TABLE "user" (
	 "username" varchar(20,0) NOT NULL,
	 "password" varchar(20,0) NOT NULL,
	 "role" varchar(20,0) NOT NULL,
	 "lasttime" text(20,0),
	PRIMARY KEY("username")
);

-- ----------------------------
--  Records of user
-- ----------------------------
BEGIN;
INSERT INTO "user" VALUES ('admin', 'admin1', 'admin', '2016-06-24 01:34:28');
INSERT INTO "user" VALUES ('S1001', 'S1001', 'student', '2016-06-23 08:28:48');
INSERT INTO "user" VALUES ('S1002', 'S1002', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1003', 'S1003', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1004', 'S1004', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1005', 'S1005', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1006', 'S1006', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1007', 'S1007', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1008', 'S1008', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1009', 'S1009', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1010', 'S1010', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1011', 'S1011', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1012', 'S1012', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1013', 'S1013', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1014', 'S1014', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1015', 'S1015', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1016', 'S1016', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1017', 'S1017', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1018', 'S1018', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1019', 'S1019', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1020', 'S1020', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1021', 'S1021', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1022', 'S1022', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1023', 'S1023', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1024', 'S1024', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1025', 'S1025', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1026', 'S1026', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1027', 'S1027', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1028', 'S1028', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1029', 'S1029', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1030', 'S1030', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1031', 'S1031', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1032', 'S1032', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1033', 'S1033', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1034', 'S1034', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1035', 'S1035', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1036', 'S1036', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1037', 'S1037', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1038', 'S1038', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1039', 'S1039', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1040', 'S1040', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1041', 'S1041', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1042', 'S1042', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1043', 'S1043', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1044', 'S1044', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1045', 'S1045', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1046', 'S1046', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1047', 'S1047', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1048', 'S1048', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1049', 'S1049', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1050', 'S1050', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1051', 'S1051', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1052', 'S1052', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1053', 'S1053', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1054', 'S1054', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1055', 'S1055', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1056', 'S1056', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1057', 'S1057', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1058', 'S1058', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1059', 'S1059', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1060', 'S1060', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1061', 'S1061', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1062', 'S1062', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1063', 'S1063', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1064', 'S1064', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1065', 'S1065', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1066', 'S1066', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1067', 'S1067', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1068', 'S1068', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1069', 'S1069', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1070', 'S1070', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1071', 'S1071', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1072', 'S1072', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1073', 'S1073', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1074', 'S1074', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1075', 'S1075', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1076', 'S1076', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1077', 'S1077', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1078', 'S1078', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1079', 'S1079', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1080', 'S1080', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1081', 'S1081', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1082', 'S1082', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1083', 'S1083', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1084', 'S1084', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1085', 'S1085', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1086', 'S1086', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1087', 'S1087', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1088', 'S1088', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1089', 'S1089', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1090', 'S1090', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1091', 'S1091', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1092', 'S1092', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1093', 'S1093', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1094', 'S1094', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1095', 'S1095', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1096', 'S1096', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1097', 'S1097', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1098', 'S1098', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1099', 'S1099', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1100', 'S1100', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1101', 'S1101', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1102', 'S1102', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1103', 'S1103', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1104', 'S1104', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1105', 'S1105', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1106', 'S1106', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1107', 'S1107', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1108', 'S1108', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1109', 'S1109', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1110', 'S1110', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1111', 'S1111', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1112', 'S1112', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1113', 'S1113', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1114', 'S1114', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1115', 'S1115', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1116', 'S1116', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1117', 'S1117', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1118', 'S1118', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1119', 'S1119', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1120', 'S1120', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1121', 'S1121', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1122', 'S1122', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1123', 'S1123', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1124', 'S1124', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1125', 'S1125', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1126', 'S1126', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1127', 'S1127', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1128', 'S1128', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1129', 'S1129', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1130', 'S1130', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1131', 'S1131', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1132', 'S1132', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1133', 'S1133', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1134', 'S1134', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S1135', 'S1135', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2001', 'T2001', 'teacher', '2016-06-23 09:10:34');
INSERT INTO "user" VALUES ('T2002', 'T2002', 'teacher', '2016-06-22 23:05:17');
INSERT INTO "user" VALUES ('T2003', 'T2003', 'teacher', '2016-06-22 18:24:22');
INSERT INTO "user" VALUES ('T2004', 'T2004', 'teacher', '2016-06-22 18:29:41');
INSERT INTO "user" VALUES ('T2005', 'T2005', 'teacher', '2016-06-22 18:30:31');
INSERT INTO "user" VALUES ('T2006', 'T2006', 'teacher', '2016-06-22 18:31:49');
INSERT INTO "user" VALUES ('T2007', 'T2007', 'teacher', '2016-06-22 18:33:15');
INSERT INTO "user" VALUES ('T2008', 'T2008', 'teacher', '2016-06-22 18:34:24');
INSERT INTO "user" VALUES ('T2009', 'T2009', 'teacher', '2016-06-22 18:36:49');
INSERT INTO "user" VALUES ('T2010', 'T2010', 'teacher', '2016-06-22 18:37:09');
INSERT INTO "user" VALUES ('T2011', 'T2011', 'teacher', '2016-06-22 18:39:18');
INSERT INTO "user" VALUES ('T2012', 'T2012', 'teacher', '2016-06-22 18:40:01');
INSERT INTO "user" VALUES ('T2013', 'T2013', 'teacher', '2016-06-22 18:40:45');
INSERT INTO "user" VALUES ('T2014', 'T2014', 'teacher', '2016-06-22 18:41:33');
INSERT INTO "user" VALUES ('T2015', 'T2015', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2016', 'T2016', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2017', 'T2017', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2020', 'T2020', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2021', 'T2021', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2022', 'T2022', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2023', 'T2023', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2024', 'T2024', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2025', 'T2025', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2026', 'T2026', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2027', 'T2027', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2028', 'T2028', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2029', 'T2029', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2030', 'T2030', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2031', 'T2031', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2032', 'T2032', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2033', 'T2033', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2034', 'T2034', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2035', 'T2035', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2036', 'T2036', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2037', 'T2037', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2038', 'T2038', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2039', 'T2039', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2040', 'T2040', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2041', 'T2041', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2042', 'T2042', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2043', 'T2043', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2044', 'T2044', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2045', 'T2045', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2046', 'T2046', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2047', 'T2047', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2048', 'T2048', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2049', 'T2049', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2050', 'T2050', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2051', 'T2051', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2052', 'T2052', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2053', 'T2053', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2054', 'T2054', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2055', 'T2055', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2056', 'T2056', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2057', 'T2057', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2058', 'T2058', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2059', 'T2059', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2060', 'T2060', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2061', 'T2061', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2062', 'T2062', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2063', 'T2063', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2064', 'T2064', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2065', 'T2065', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2066', 'T2066', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2067', 'T2067', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('T2068', 'T2068', 'teacher', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3008', 'S3008', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3009', 'S3009', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3010', 'S3010', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3011', 'S3011', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3012', 'S3012', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3013', 'S3013', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3014', 'S3014', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3015', 'S3015', 'student', '您是第一次登陆系统');
INSERT INTO "user" VALUES ('S3016', 'S3016', 'student', '您是第一次登陆系统');
COMMIT;

PRAGMA foreign_keys = true;
