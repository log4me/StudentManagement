/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:53:49 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS "student";
CREATE TABLE "student" (
	 "sno" varchar(20,0) NOT NULL,
	 "sname" varchar(20,0) NOT NULL,
	 "ssex" varchar(20,0) NOT NULL,
	 "sage" integer(3,0) NOT NULL,
	 "sdept" varchar(20,0) NOT NULL,
	 "sphone" varchar(20,0),
	PRIMARY KEY("sno")
);

-- ----------------------------
--  Records of student
-- ----------------------------
BEGIN;
INSERT INTO "student" VALUES ('S1001', '汪守旭', '男', 20, '计算机科学与技术', 18862103721);
INSERT INTO "student" VALUES ('S1002', '陶  北', '女', 20, '网络工程', 18862103722);
INSERT INTO "student" VALUES ('S1003', '周子怡', '女', 20, '信息管理', 18862103723);
INSERT INTO "student" VALUES ('S1004', '冯子文', '男', 20, '嵌入式软件工程', 18862103724);
INSERT INTO "student" VALUES ('S1005', '史雨萌', '男', 20, '物联网', 18862103725);
INSERT INTO "student" VALUES ('S1006', '向  那', '女', 20, '软件工程', 18862103726);
INSERT INTO "student" VALUES ('S1007', '周丹全', '女', 20, '计算机科学与技术', 18862103727);
INSERT INTO "student" VALUES ('S1008', '胡玲玲', '男', 20, '网络工程', 18862103728);
INSERT INTO "student" VALUES ('S1009', '刘善奇', '男', 20, '信息管理', 18862103729);
INSERT INTO "student" VALUES ('S1010', '徐亚宁', '女', 20, '嵌入式软件工程', 18862103730);
INSERT INTO "student" VALUES ('S1011', '来国庆', '女', 20, '物联网', 18862103731);
INSERT INTO "student" VALUES ('S1012', '魏文华', '男', 20, '软件工程', 18862103732);
INSERT INTO "student" VALUES ('S1013', '胡高峰', '男', 20, '计算机科学与技术', 18862103733);
INSERT INTO "student" VALUES ('S1014', '王明肖', '女', 20, '网络工程', 18862103734);
INSERT INTO "student" VALUES ('S1015', '岳家乐', '女', 20, '信息管理', 18862103735);
INSERT INTO "student" VALUES ('S1016', '曹明明', '男', 20, '嵌入式软件工程', 18862103736);
INSERT INTO "student" VALUES ('S1017', '杨远哲', '男', 20, '物联网', 18862103737);
INSERT INTO "student" VALUES ('S1018', '沈川盈', '女', 20, '软件工程', 18862103738);
INSERT INTO "student" VALUES ('S1019', '王晓森', '女', 20, '计算机科学与技术', 18862103739);
INSERT INTO "student" VALUES ('S1020', '沈  立', '男', 20, '网络工程', 18862103740);
INSERT INTO "student" VALUES ('S1021', '徐福杰', '男', 20, '信息管理', 18862103741);
INSERT INTO "student" VALUES ('S1022', '周元伟', '女', 20, '嵌入式软件工程', 18862103742);
INSERT INTO "student" VALUES ('S1023', '李发超', '女', 20, '物联网', 18862103743);
INSERT INTO "student" VALUES ('S1024', '胡宝玉', '男', 20, '软件工程', 18862103744);
INSERT INTO "student" VALUES ('S1025', '陈志哲', '男', 20, '计算机科学与技术', 18862103745);
INSERT INTO "student" VALUES ('S1026', '孙  昌', '女', 20, '网络工程', 18862103746);
INSERT INTO "student" VALUES ('S1027', '杨  筱', '女', 19, '信息管理', 18862103747);
INSERT INTO "student" VALUES ('S1028', '丁国旭', '男', 19, '嵌入式软件工程', 18862103748);
INSERT INTO "student" VALUES ('S1029', '陈亚齐', '男', 19, '物联网', 18862103749);
INSERT INTO "student" VALUES ('S1030', '周保国', '女', 19, '软件工程', 18862103750);
INSERT INTO "student" VALUES ('S1031', '胡正圆', '女', 19, '计算机科学与技术', 18862103751);
INSERT INTO "student" VALUES ('S1032', '来定忍', '男', 19, '网络工程', 18862103752);
INSERT INTO "student" VALUES ('S1033', '寇星宇', '男', 19, '信息管理', 18862103753);
INSERT INTO "student" VALUES ('S1034', '陈  言', '女', 19, '嵌入式软件工程', 17751124387);
INSERT INTO "student" VALUES ('S1035', '唐甜甜', '女', 19, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1036', '包文菲', '男', 19, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1037', '张小蝶', '男', 19, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1038', '王明婷', '女', 19, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1039', '尚稳琦', '女', 19, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1040', '汪地程', '男', 19, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1041', '龙光好', '男', 19, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1042', '李  耿', '女', 19, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1043', '王卓云', '女', 19, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1044', '刘荣荣', '男', 19, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1045', '陈石康', '男', 19, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1046', '张博煜', '女', 19, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1047', '汪  甜', '女', 19, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1048', '赵  萍', '男', 19, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1049', '来韩阳', '男', 19, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1050', '张文景', '女', 19, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1051', '宴富林', '女', 19, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1052', '李东生', '男', 19, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1053', '李长辉', '男', 19, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1054', '王康', '女', 19, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1055', '王思杰', '女', 19, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1056', '封加乐', '男', 19, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1057', '黄州', '男', 19, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1058', '侯永权', '女', 19, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1059', '顾明雪', '女', 19, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1060', '于海文', '男', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1061', '王云', '男', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1062', '孙成艳', '女', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1063', '李思杰', '女', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1064', '孙圆', '男', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1065', '王雪婷', '男', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1066', '顾双银', '女', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1067', '顾祥伟', '女', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1068', '盛中丽', '男', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1069', '孙文杰', '男', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1070', '黄加乐', '女', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1071', '李顺兄', '女', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1072', '孙苏静', '男', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1073', '李芳玲', '男', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1074', '封静', '女', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1075', '李振阳', '女', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1076', '李显光', '男', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1077', '朱婷婷', '男', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1078', '王发清', '女', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1079', '李倩梅', '女', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1080', '李文静', '男', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1081', '王发田', '男', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1082', '李培壮', '女', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1083', '朱玉亮', '女', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1084', '李如意', '男', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1085', '江思晗', '男', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1086', '江思瑶', '女', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1087', '吴红香', '女', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1088', '宋正兴', '男', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1089', '邢佳雪', '男', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1090', '王丽君', '女', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1091', '田雯丽', '女', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1092', '田亚轩', '男', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1093', '黄成', '男', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1094', '王焘', '女', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1095', '何美娇', '女', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1096', '王玉蓉', '男', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1097', '孟欣雨', '男', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1098', '张鹏', '女', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1099', '杨海钰', '女', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1100', '田美馨', '男', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1101', '陈宗喜', '男', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1102', '杨小龙', '女', 21, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1103', '殷晓红', '女', 21, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1104', '杨欣雨', '男', 21, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1105', '公立发', '男', 21, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1106', '许生秦', '女', 21, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1107', '陈玉蓉', '女', 21, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1108', '孟鑫', '男', 18, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1109', '张添', '男', 18, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1110', '马文婷', '女', 18, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1111', '何  鹏', '女', 18, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1112', '吴海龙', '男', 18, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1113', '陈宗贤', '男', 18, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1114', '李文龙', '女', 18, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1115', '邢志潇', '女', 18, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1116', '何占雄', '男', 18, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1117', '陈德乾', '男', 18, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1118', '王怀川', '女', 18, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1119', '殷  国', '女', 18, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1120', '许  涛', '男', 18, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1121', '邢  丹', '男', 18, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1122', '王晓兰', '女', 18, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1123', '陈安娜', '女', 18, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1124', '何丽佳', '男', 18, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1125', '王丽娜', '男', 18, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1126', '许鸿燕', '女', 18, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1127', '王紫璇', '女', 18, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1128', '殷丽蓉', '男', 18, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1129', '吴三泰', '男', 18, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S1130', '吴延平', '女', 18, '嵌入式软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1131', '田学才', '女', 18, '物联网', 17751124388);
INSERT INTO "student" VALUES ('S1132', '田开旭', '男', 18, '软件工程', 17751124388);
INSERT INTO "student" VALUES ('S1133', '田玉娇', '男', 18, '计算机科学与技术', 17751124388);
INSERT INTO "student" VALUES ('S1134', '田丽叶', '女', 18, '网络工程', 17751124388);
INSERT INTO "student" VALUES ('S1135', '李文杰', '女', 18, '信息管理', 17751124388);
INSERT INTO "student" VALUES ('S3008', '杨昳', '男', 21, '计算机科学与技术', 17755122765);
INSERT INTO "student" VALUES ('S3009', '陈治国', '女', 22, '网络工程', 17755122766);
INSERT INTO "student" VALUES ('S3010', '李小龙', '男', 18, '信息管理', 17755122767);
INSERT INTO "student" VALUES ('S3011', '赵倩', '女', 19, '嵌入式软件工程', 17755122768);
INSERT INTO "student" VALUES ('S3012', '屠贝贝', '男', 20, '物联网', 17755122769);
INSERT INTO "student" VALUES ('S3013', '张军', '女', 20, '软件工程', 17755122770);
INSERT INTO "student" VALUES ('S3014', '李杰', '男', 18, '计算机科学与技术', 17755122771);
INSERT INTO "student" VALUES ('S3015', '张恩', '女', 21, '网络工程', 17755122772);
INSERT INTO "student" VALUES ('S3016', '阳光', '男', 19, '信息管理', 17755122773);
COMMIT;

PRAGMA foreign_keys = true;
