/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:54:07 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS "course";
CREATE TABLE "course" (
	 "cno" varchar(20,0) NOT NULL,
	 "cname" varchar(20,0) NOT NULL,
	 "ccredit" integer(2,0) NOT NULL,
	PRIMARY KEY("cno")
);

-- ----------------------------
--  Records of course
-- ----------------------------
BEGIN;
INSERT INTO "course" VALUES ('COM0002', '高等数学上', 5);
INSERT INTO "course" VALUES ('COM0003', '线性代数', 3);
INSERT INTO "course" VALUES ('COM0004', '概率论统计', 3);
INSERT INTO "course" VALUES ('COM0005', '大学英语一', 5);
INSERT INTO "course" VALUES ('COM0006', '软工概论', 5);
INSERT INTO "course" VALUES ('COM0007', '思想品德与法律修养', 3);
INSERT INTO "course" VALUES ('COM0008', '数据库原理与设计', 4);
INSERT INTO "course" VALUES ('COM0009', '数据库课程设计', 4);
INSERT INTO "course" VALUES ('COM0010', '大学英语二', 5);
INSERT INTO "course" VALUES ('COM0011', '翻译与写作', 3);
INSERT INTO "course" VALUES ('COM0012', '高级口语', 4);
INSERT INTO "course" VALUES ('COM0013', '高等数学下', 5);
INSERT INTO "course" VALUES ('COM0014', '普通物理上', 3);
INSERT INTO "course" VALUES ('COM0015', '普通物理下', 4);
INSERT INTO "course" VALUES ('COM0016', '军事理论', 4);
INSERT INTO "course" VALUES ('COM0017', '军事技能', 4);
INSERT INTO "course" VALUES ('COM0018', '形势与政策', 5);
INSERT INTO "course" VALUES ('COM0019', '算法导论', 2);
INSERT INTO "course" VALUES ('COM0020', '计算机网络', 4);
INSERT INTO "course" VALUES ('COM0021', '计算机组成与系统结构', 4);
INSERT INTO "course" VALUES ('COM0022', '汇编语言程序设计', 3);
INSERT INTO "course" VALUES ('COM0023', '编译原理', 2);
INSERT INTO "course" VALUES ('COM0024', '操作系统', 3);
INSERT INTO "course" VALUES ('COM0025', '计算机导论', 4);
INSERT INTO "course" VALUES ('COM0026', '模拟电路与数字电路', 5);
INSERT INTO "course" VALUES ('COM0027', 'C++程序设计', 3);
INSERT INTO "course" VALUES ('COM0028', '数据结构', 5);
INSERT INTO "course" VALUES ('COM0029', '离散数学', 5);
INSERT INTO "course" VALUES ('COM0030', '人工智能', 2);
INSERT INTO "course" VALUES ('COM0001', 'C语言程序设计', 4);
COMMIT;

PRAGMA foreign_keys = true;
