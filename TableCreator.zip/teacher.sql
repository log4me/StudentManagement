/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:53:37 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS "teacher";
CREATE TABLE "teacher" (
	 "tno" varchar(20,0) NOT NULL,
	 "tname" varchar(20,0) NOT NULL,
	 "tphone" varchar(20,0) NOT NULL,
	PRIMARY KEY("tno")
);

-- ----------------------------
--  Records of teacher
-- ----------------------------
BEGIN;
INSERT INTO "teacher" VALUES ('T2001', '詹海云', 18823567856);
INSERT INTO "teacher" VALUES ('T2002', '温静', 18823567857);
INSERT INTO "teacher" VALUES ('T2003', '曾益峰', 18823567858);
INSERT INTO "teacher" VALUES ('T2004', '魏星', 18823567859);
INSERT INTO "teacher" VALUES ('T2005', '张朔', 18823567860);
INSERT INTO "teacher" VALUES ('T2006', '党跃武', 18823567861);
INSERT INTO "teacher" VALUES ('T2007', '戚亚男', 18823567862);
INSERT INTO "teacher" VALUES ('T2008', '陈建伟', 18823567863);
INSERT INTO "teacher" VALUES ('T2009', '尹进', 18823567864);
INSERT INTO "teacher" VALUES ('T2010', '曾益峰', 18823567865);
INSERT INTO "teacher" VALUES ('T2011', '孙克金', 18823567866);
INSERT INTO "teacher" VALUES ('T2012', '李娟', 18823567867);
INSERT INTO "teacher" VALUES ('T2013', '邓屹立', 18823567868);
INSERT INTO "teacher" VALUES ('T2014', '成北良', 18823567869);
INSERT INTO "teacher" VALUES ('T2015', '杨皓岚', 18823567870);
INSERT INTO "teacher" VALUES ('T2016', '林祎', 18312345708);
INSERT INTO "teacher" VALUES ('T2017', '张怡', 18312345709);
INSERT INTO "teacher" VALUES ('T2020', '陆晓霞', 18312345712);
INSERT INTO "teacher" VALUES ('T2021', '林祎', 18312345713);
INSERT INTO "teacher" VALUES ('T2022', '郝清华', 18312345714);
INSERT INTO "teacher" VALUES ('T2023', '谢凌志', 18312345715);
INSERT INTO "teacher" VALUES ('T2024', '姚向征', 18312345716);
INSERT INTO "teacher" VALUES ('T2025', '李晓涛', 18312345717);
INSERT INTO "teacher" VALUES ('T2026', '王智勇', 18312345718);
INSERT INTO "teacher" VALUES ('T2027', '王刚', 18312345719);
INSERT INTO "teacher" VALUES ('T2028', '李昆', 18312345720);
INSERT INTO "teacher" VALUES ('T2029', '周克林', 17734672403);
INSERT INTO "teacher" VALUES ('T2030', '蒲于文', 17734672404);
INSERT INTO "teacher" VALUES ('T2031', '陈顺礼', 17734672405);
INSERT INTO "teacher" VALUES ('T2032', '陈长虹', 17734672406);
INSERT INTO "teacher" VALUES ('T2033', '马继刚', 17734672407);
INSERT INTO "teacher" VALUES ('T2034', '刘锦超', 17734672408);
INSERT INTO "teacher" VALUES ('T2035', '贺端威', 17734672409);
INSERT INTO "teacher" VALUES ('T2036', '原祖杰', 17734672410);
INSERT INTO "teacher" VALUES ('T2037', '陈红莹', 17734672411);
INSERT INTO "teacher" VALUES ('T2038', '刘娟', 17734672412);
INSERT INTO "teacher" VALUES ('T2039', '刘孝利', 17734672413);
INSERT INTO "teacher" VALUES ('T2040', '贾舜宸', 17734672414);
INSERT INTO "teacher" VALUES ('T2041', '姚乐野', 17734672415);
INSERT INTO "teacher" VALUES ('T2042', '杨晓琳', 17734672416);
INSERT INTO "teacher" VALUES ('T2043', '陈明惠', 17734672417);
INSERT INTO "teacher" VALUES ('T2044', '彭放', 17734672418);
INSERT INTO "teacher" VALUES ('T2045', '李栓久', 17734672419);
INSERT INTO "teacher" VALUES ('T2046', '李萍', 17734672420);
INSERT INTO "teacher" VALUES ('T2047', '华国春', 17734672421);
INSERT INTO "teacher" VALUES ('T2048', '邝小渝', 17734672422);
INSERT INTO "teacher" VALUES ('T2049', '蒋刚', 17734672423);
INSERT INTO "teacher" VALUES ('T2050', '田贵明', 17734672424);
INSERT INTO "teacher" VALUES ('T2051', '王鹏', 13332456789);
INSERT INTO "teacher" VALUES ('T2052', '伍红雨', 13332456790);
INSERT INTO "teacher" VALUES ('T2053', '毕中胜', 13332456791);
INSERT INTO "teacher" VALUES ('T2054', '张伟', 13332456792);
INSERT INTO "teacher" VALUES ('T2055', '赵进', 13332456793);
COMMIT;

PRAGMA foreign_keys = true;
