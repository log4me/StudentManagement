/*
 Navicat Premium Data Transfer

 Source Server         : School_copy_copy_copy
 Source Server Type    : SQLite
 Source Server Version : 3008004
 Source Database       : main

 Target Server Type    : SQLite
 Target Server Version : 3008004
 File Encoding         : utf-8

 Date: 06/24/2016 23:53:42 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for tc
-- ----------------------------
DROP TABLE IF EXISTS "tc";
CREATE TABLE "tc" (
	 "tno" varchar(20,0) NOT NULL,
	 "cno" varchar(20,0) NOT NULL,
	 "clocation" varchear(20,0) NOT NULL,
	 "cmaxcount" integer(3,0) NOT NULL,
	 "ctime" text(20,0) NOT NULL,
	 "cstatus" varchar(5,0),
	PRIMARY KEY("tno","cno")
);

-- ----------------------------
--  Records of tc
-- ----------------------------
BEGIN;
INSERT INTO "tc" VALUES ('T2001', 'COM0002', X'e980b8e5a4abe6a5bc', 85, '一一', null);
INSERT INTO "tc" VALUES ('T2001', 'COM0004', X'e69687e6809de6a5bc', 30, '二一', '已提交');
INSERT INTO "tc" VALUES ('T2002', 'COM0003', X'e58d9ae8bf9ce6a5bc', 30, '一一', null);
INSERT INTO "tc" VALUES ('T2002', 'COM0029', X'e79086e5b7a5e6a5bc', 36, '一三', null);
INSERT INTO "tc" VALUES ('T2003', 'COM0005', X'e69687e6809de6a5bc', 30, '三一', null);
INSERT INTO "tc" VALUES ('T2004', 'COM0007', X'20e980b8e5a4abe6a5bc', 45, '一五', null);
INSERT INTO "tc" VALUES ('T2005', 'COM0006', X'20e980b8e5a4abe6a5bc', 30, '四三', null);
INSERT INTO "tc" VALUES ('T2006', 'COM0009', X'e69687e6809de6a5bc', 60, '五二', null);
INSERT INTO "tc" VALUES ('T2007', 'COM0011', X'e69687e6809de6a5bc', 35, '一二', null);
INSERT INTO "tc" VALUES ('T2008', 'COM0014', X'e4b89ce69599e6a5bc', 30, '二五', null);
INSERT INTO "tc" VALUES ('T2009', 'COM0016', X'e4b89ce69599e6a5bc', 40, '三三', null);
INSERT INTO "tc" VALUES ('T2010', 'COM0018', X'e58d9ae8bf9ce6a5bc', 36, '四三', null);
INSERT INTO "tc" VALUES ('T2011', 'COM0025', X'e4b89ce69599e6a5bc', 20, '六二', null);
INSERT INTO "tc" VALUES ('T2011', 'COM0027', X'e980b8e5a4abe6a5bc', 30, '四四', null);
INSERT INTO "tc" VALUES ('T2012', 'COM0001', X'e79086e5b7a5e6a5bc', 35, '五五', null);
INSERT INTO "tc" VALUES ('T2013', 'COM0030', X'e79086e5b7a5e6a5bc', 35, '四二', null);
INSERT INTO "tc" VALUES ('T2014', 'COM0019', X'e980b8e5a4abe6a5bc', 35, '四一', null);
COMMIT;

PRAGMA foreign_keys = true;
